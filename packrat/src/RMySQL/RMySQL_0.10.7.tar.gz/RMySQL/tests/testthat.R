library(testthat)
library(RMySQL)

test_check("RMySQL")
