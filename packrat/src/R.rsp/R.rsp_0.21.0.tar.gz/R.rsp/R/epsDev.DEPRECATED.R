epsDev <- function(label, width=6, height=aspect*width, aspect=1, ..., path="figures", safe=TRUE, force=FALSE) {
  .Defunct("R.devices::toEPS")
}


##############################################################################
# HISTORY:
# 2015-01-18
# o CLEANUP: Formally defunct epsDev().
# 2013-05-06
# o CLEANUP: Formally deprecated epsDev().
##############################################################################
